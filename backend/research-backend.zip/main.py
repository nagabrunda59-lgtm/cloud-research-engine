
from functools import lru_cache
import re

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.concurrency import run_in_threadpool
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer


app = FastAPI(title="Cloud Research Engine")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ResearchQuery(BaseModel):
    topic: str = Field(min_length=1, max_length=500)
    page: int = Field(default=1, ge=1)
    per_page: int = Field(default=20, ge=1, le=100)


class GapAnalysisRequest(BaseModel):
    topic: str = Field(min_length=1, max_length=500)
    per_page: int = Field(default=50, ge=10, le=100)


class NoveltyAnalysisRequest(BaseModel):
    topic: str = Field(min_length=1, max_length=500)
    per_page: int = Field(default=50, ge=10, le=100)


@lru_cache(maxsize=1)
def get_embedding_model():
    return SentenceTransformer(
        "sentence-transformers/all-MiniLM-L6-v2"
    )


def reconstruct_abstract(inverted_index):
    """Convert OpenAlex's inverted-index abstract into readable text."""
    if not inverted_index:
        return ""

    positions = {}

    for word, indexes in inverted_index.items():
        for index in indexes:
            positions[index] = word

    return " ".join(
        positions[index] for index in sorted(positions)
    )


async def fetch_openalex_papers(topic, page=1, per_page=20):
    """Retrieve academic papers and available metadata from OpenAlex."""
    params = {
        "search": topic,
        "page": page,
        "per-page": per_page,
        "sort": "relevance_score:desc",
    }

    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.get(
                "https://api.openalex.org/works",
                params=params,
            )
            response.raise_for_status()
            result = response.json()

    except httpx.HTTPError as exc:
        raise HTTPException(
            status_code=502,
            detail="Academic search provider is temporarily unavailable.",
        ) from exc

    papers = []
    seen_titles = set()

    for work in result.get("results", []):
        title = work.get("display_name") or "Untitled"
        normalized_title = re.sub(
            r"[^a-z0-9]+",
            " ",
            title.casefold(),
        ).strip()

        # Remove duplicate title records from this result page.
        if normalized_title in seen_titles:
            continue

        seen_titles.add(normalized_title)

        authorships = work.get("authorships") or []

        authors = [
            item.get("author", {}).get("display_name", "")
            for item in authorships
            if item.get("author")
        ]

        location = work.get("primary_location") or {}
        source = location.get("source") or {}
        open_access = work.get("open_access") or {}

        abstract = reconstruct_abstract(
            work.get("abstract_inverted_index")
        )

        papers.append({
            "id": work.get("id"),
            "title": title,
            "authors": authors,
            "year": work.get("publication_year"),
            "doi": work.get("doi"),
            "abstract": abstract or None,
            "citations": work.get("cited_by_count", 0),
            "journal": source.get("display_name"),
            "open_access": open_access.get("is_oa", False),
            "pdf_url": open_access.get("oa_url"),
            "url": work.get("doi") or work.get("id"),
        })

    return result, papers


def rank_papers(topic, papers):
    """Rank papers using sentence embeddings and cosine similarity."""
    if not papers:
        return papers

    model = get_embedding_model()

    texts = [
        f"{paper['title']}. {paper['abstract'] or ''}".strip()
        for paper in papers
    ]

    embeddings = model.encode(
        [topic] + texts,
        normalize_embeddings=True,
        show_progress_bar=False,
    )

    query_embedding = embeddings[0].reshape(1, -1)
    paper_embeddings = embeddings[1:]

    scores = cosine_similarity(
        query_embedding,
        paper_embeddings,
    )[0]

    for paper, score in zip(papers, scores):
        paper["similarity_score"] = round(float(score), 4)

    papers.sort(
        key=lambda paper: paper["similarity_score"],
        reverse=True,
    )

    return papers


def normalize_concept(value):
    """Normalize a concept for filtering and duplicate detection."""
    if not isinstance(value, str):
        return ""

    value = value.casefold().strip()
    value = re.sub(r"[^a-z0-9\s-]", " ", value)
    return " ".join(value.split())


def build_gap_analysis(topic, papers):
    """
    Identify recurring and underrepresented concepts in retrieved papers.

    Underrepresented concepts are candidate gaps, not proof of novelty.
    """
    usable_papers = [
        paper for paper in papers
        if paper.get("title") or paper.get("abstract")
    ]

    abstract_count = sum(
        bool(paper.get("abstract")) for paper in usable_papers
    )

    base = {
        "topic": topic,
        "provider": "OpenAlex",
        "paper_count": len(usable_papers),
        "abstract_count": abstract_count,
        "abstract_coverage_percent": round(
            100 * abstract_count / len(usable_papers), 1
        ) if usable_papers else 0,
        "themes": [],
        "candidate_gaps": [],
    }

    if len(usable_papers) < 3:
        return {
            **base,
            "status": "insufficient_evidence",
            "message": (
                "At least 3 usable papers are needed for an initial "
                "comparison. Try a broader research query."
            ),
            "limitations": [
                "The retrieved papers may not represent the full literature.",
                "Text frequency alone cannot establish novelty.",
            ],
        }

    documents = [
        f"{paper.get('title') or ''}. {paper.get('abstract') or ''}"
        for paper in usable_papers
    ]

    try:
        vectorizer = TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),
            min_df=2,
            max_df=0.85,
            token_pattern=r"(?u)\b[a-zA-Z][a-zA-Z-]{2,}\b",
            max_features=1500,
        )

        matrix = vectorizer.fit_transform(documents)
        terms = vectorizer.get_feature_names_out()

    except ValueError:
        return {
            **base,
            "status": "insufficient_text",
            "message": (
                "There is not enough repeated text to identify themes. "
                "More abstracts or a broader search may help."
            ),
            "limitations": [
                "Text frequency alone cannot establish novelty.",
            ],
        }

    theme_items = []

    for column, term in enumerate(terms):
        indexes = matrix[:, column].nonzero()[0]
        count = len(indexes)

        if count < 2:
            continue

        mean_weight = sum(
            float(matrix[index, column]) for index in indexes
        ) / count

        supporting_papers = [
            {
                "title": usable_papers[index].get("title"),
                "year": usable_papers[index].get("year"),
                "url": usable_papers[index].get("url"),
            }
            for index in indexes[:5]
        ]

        theme_items.append({
            "theme": term,
            "paper_count": count,
            "coverage_percent": round(
                100 * count / len(usable_papers), 1
            ),
            "mean_tfidf_weight": round(mean_weight, 4),
            "supporting_papers": supporting_papers,
        })

    themes = sorted(
        theme_items,
        key=lambda item: (
            -item["paper_count"],
            -item["mean_tfidf_weight"],
        ),
    )[:10]

    maximum_coverage_count = max(
        2, int(len(usable_papers) * 0.20)
    )

    underrepresented = [
        item for item in theme_items
        if 2 <= item["paper_count"] <= maximum_coverage_count
    ]

    underrepresented.sort(
        key=lambda item: (
            item["paper_count"],
            -item["mean_tfidf_weight"],
        )
    )

    candidate_gaps = []
    seen_concepts = set()

    for item in underrepresented:
        concept = normalize_concept(item["theme"])

        if not concept or concept in seen_concepts:
            continue

        seen_concepts.add(concept)

        candidate_gaps.append({
            "candidate": (
                f"Limited representation of '{item['theme']}' "
                "in the retrieved sample"
            ),
            "concept": item["theme"],
            "papers_mentioning": item["paper_count"],
            "coverage_percent": item["coverage_percent"],
            "evidence": item["supporting_papers"],
            "interpretation": (
                "This concept appears in a relatively small share of "
                "the retrieved papers. Review the sources and search "
                "further before treating it as a research gap."
            ),
        })

        if len(candidate_gaps) >= 10:
            break

    message = (
        "Candidate gaps require verification against additional "
        "literature and the full text of relevant papers."
        if candidate_gaps
        else (
            "No clearly underrepresented recurring concepts were found "
            "using this method. This does not mean research gaps "
            "do not exist."
        )
    )

    return {
        **base,
        "status": "completed",
        "method": "TF-IDF concept frequency across retrieved paper text",
        "message": message,
        "themes": themes,
        "candidate_gaps": candidate_gaps,
        "limitations": [
            "The retrieved papers are only a sample of the literature.",
            "Missing abstracts can hide important research themes.",
            "Text frequency does not establish research novelty.",
            "Candidate gaps require additional searches and human review.",
        ],
    }


def build_novelty_ideas(topic, gap_analysis):
    """
    Generate filtered research directions from candidate gaps.

    These are suggestions for investigation, not verified novel
    contributions. This function does not independently prove novelty.
    """
    if gap_analysis.get("status") != "completed":
        return []

    generic_terms = {
        "using",
        "based",
        "approach",
        "method",
        "methods",
        "results",
        "study",
        "research",
        "analysis",
        "review",
        "application",
        "applications",
        "intelligence analysis",
    }

    ideas = []
    seen_concepts = set()

    for gap in gap_analysis.get("candidate_gaps", []):
        raw_concept = gap.get("concept", "")
        concept = normalize_concept(raw_concept)

        if not concept:
            continue

        words = concept.split()

        # Remove generic phrases that do not express a useful topic.
        if concept in generic_terms:
            continue

        # Avoid very short, broad fragments and excessively long phrases.
        if len(words) > 3 or any(len(word) < 3 for word in words):
            continue

        if concept in seen_concepts:
            continue

        seen_concepts.add(concept)

        evidence = gap.get("evidence", [])
        evidence_titles = []
        seen_titles = set()
        supporting_details = []

        for paper in evidence:
            if not isinstance(paper, dict):
                continue

            title = paper.get("title")

            if not isinstance(title, str) or not title.strip():
                continue

            title = title.strip()
            title_key = normalize_concept(title)

            if not title_key or title_key in seen_titles:
                continue

            seen_titles.add(title_key)
            evidence_titles.append(title)

            supporting_details.append({
                "title": title,
                "year": paper.get("year"),
                "url": paper.get("url"),
            })

        # A candidate without distinct supporting titles is too weak
        # to present as an evidence-backed suggestion.
        if len(evidence_titles) < 2:
            continue

        ideas.append({
            "idea": (
                f"Investigate how '{raw_concept}' relates to {topic}, "
                "starting with a specific limitation documented "
                "in existing research."
            ),
            "based_on_gap": gap.get("candidate"),
            "research_question": (
                f"What limitations remain in existing approaches "
                f"related to '{raw_concept}' in {topic}, and how "
                "could those limitations be measured and addressed?"
            ),
            "possible_contribution": (
                "Identify a documented limitation, develop or adapt "
                "a suitable method, compare it against relevant "
                "baselines, and evaluate it with appropriate datasets "
                "and measurable metrics."
            ),
            "evidence_paper_count": gap.get(
                "papers_mentioning", len(evidence_titles)
            ),
            "evidence_coverage_percent": gap.get(
                "coverage_percent", 0
            ),
            "supporting_papers": evidence_titles,
            "supporting_paper_details": supporting_details,
            "verification_needed": [
                "Verify the supporting paper records and publication details.",
                "Read limitations and future-work sections where full text is available.",
                "Search for existing studies addressing the same research question.",
                "Check whether the candidate gap reflects missing knowledge rather than low word frequency.",
                "Define suitable datasets, baselines, and evaluation metrics.",
            ],
            "novelty_status": "unverified_candidate",
        })

        if len(ideas) >= 5:
            break

    return ideas


@app.get("/")
def home():
    return {
        "message": "Cloud Research Engine API is running!",
        "status": "connected",
    }


@app.get("/api/health")
def health():
    return {"status": "healthy"}


@app.post("/api/research/search")
async def search_research(request: ResearchQuery):
    topic = request.topic.strip()

    if not topic:
        raise HTTPException(
            status_code=400,
            detail="Please enter a research topic.",
        )

    result, papers = await fetch_openalex_papers(
        topic,
        page=request.page,
        per_page=request.per_page,
    )

    try:
        papers = await run_in_threadpool(
            rank_papers,
            topic,
            papers,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=(
                "AI ranking failed. Check that the embedding model "
                "is installed and available."
            ),
        ) from exc

    meta = result.get("meta", {})

    return {
        "topic": topic,
        "provider": "OpenAlex",
        "ranking_method": "Sentence Transformers + Cosine Similarity",
        "total_results": meta.get("count", 0),
        "page": request.page,
        "per_page": request.per_page,
        "papers": papers,
    }


@app.post("/api/research/gaps")
async def analyze_research_gaps(request: GapAnalysisRequest):
    topic = request.topic.strip()

    if not topic:
        raise HTTPException(
            status_code=400,
            detail="Please enter a research topic.",
        )

    _, papers = await fetch_openalex_papers(
        topic,
        page=1,
        per_page=request.per_page,
    )

    return await run_in_threadpool(
        build_gap_analysis,
        topic,
        papers,
    )


@app.post("/api/research/novelty")
async def analyze_research_novelty(
    request: NoveltyAnalysisRequest,
):
    topic = request.topic.strip()

    if not topic:
        raise HTTPException(
            status_code=400,
            detail="Please enter a research topic.",
        )

    _, papers = await fetch_openalex_papers(
        topic,
        page=1,
        per_page=request.per_page,
    )

    gap_analysis = await run_in_threadpool(
        build_gap_analysis,
        topic,
        papers,
    )

    ideas = await run_in_threadpool(
        build_novelty_ideas,
        topic,
        gap_analysis,
    )

    return {
        "status": gap_analysis.get("status"),
        "topic": topic,
        "provider": "OpenAlex",
        "analysis_method": (
            "Filtered TF-IDF candidate concepts followed by "
            "rule-based research direction generation"
        ),
        "paper_count": gap_analysis.get("paper_count", 0),
        "abstract_count": gap_analysis.get("abstract_count", 0),
        "candidate_gap_count": len(
            gap_analysis.get("candidate_gaps", [])
        ),
        "novelty_ideas": ideas,
        "message": (
            "These are possible research directions, not confirmed "
            "novel contributions. Verify them against existing "
            "literature before making novelty claims."
        ),
        "limitations": gap_analysis.get("limitations", []),
    }
