
from functools import lru_cache
import asyncio
import re

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.concurrency import run_in_threadpool
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sentence_transformers import SentenceTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# --------------------------------------------------
# APPLICATION
# --------------------------------------------------

app = FastAPI(title="Cloud Research Engine")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


OPENALEX_URL = "https://api.openalex.org/works"
OPENALEX_HEADERS = {
    "User-Agent": "CloudResearchEngine/1.0 (research paper discovery)"
}


# --------------------------------------------------
# REQUEST MODELS
# --------------------------------------------------

class ResearchQuery(BaseModel):
    topic: str = Field(min_length=1, max_length=500)
    page: int = Field(default=1, ge=1)
    per_page: int = Field(default=20, ge=1, le=100)
    candidate_limit: int = Field(default=100, ge=100, le=2000)


class AllResearchQuery(BaseModel):
    topic: str = Field(min_length=1, max_length=500)
    max_papers: int | None = Field(default=None, ge=1)
    batch_size: int = Field(default=100, ge=1, le=100)


class GapAnalysisRequest(BaseModel):
    topic: str = Field(min_length=1, max_length=500)
    per_page: int = Field(default=50, ge=10, le=100)
    max_papers: int | None = Field(default=200, ge=1)


class NoveltyAnalysisRequest(BaseModel):
    topic: str = Field(min_length=1, max_length=500)
    per_page: int = Field(default=50, ge=10, le=100)
    max_papers: int | None = Field(default=200, ge=1)


# --------------------------------------------------
# AI MODEL
# --------------------------------------------------

@lru_cache(maxsize=1)
def get_embedding_model():
    return SentenceTransformer(
        "sentence-transformers/all-MiniLM-L6-v2"
    )


# --------------------------------------------------
# OPENALEX HELPERS
# --------------------------------------------------

def reconstruct_abstract(inverted_index):
    if not inverted_index:
        return ""

    positions = {}

    for word, indexes in inverted_index.items():
        for index in indexes:
            positions[index] = word

    return " ".join(
        positions[index] for index in sorted(positions)
    )


def convert_openalex_work(work):
    title = work.get("display_name") or "Untitled"

    authorships = work.get("authorships") or []
    authors = [
        item.get("author", {}).get("display_name", "")
        for item in authorships
        if item.get("author")
    ]

    location = work.get("primary_location") or {}
    source = location.get("source") or {}
    open_access = work.get("open_access") or {}

    abstract = reconstruct_abstract(
        work.get("abstract_inverted_index")
    )

    doi = work.get("doi")
    paper_id = work.get("id")

    return {
        "id": paper_id,
        "title": title,
        "authors": authors,
        "year": work.get("publication_year"),
        "doi": doi,
        "abstract": abstract or None,
        "citations": work.get("cited_by_count", 0),
        "journal": source.get("display_name"),
        "open_access": open_access.get("is_oa", False),
        "pdf_url": open_access.get("oa_url"),
        "url": doi or paper_id,
    }


def deduplication_key(paper):
    paper_id = paper.get("id")
    if paper_id:
        return paper_id.casefold()

    doi = paper.get("doi")
    if doi:
        return doi.casefold()

    return re.sub(
        r"[^a-z0-9]+",
        " ",
        (paper.get("title") or "").casefold(),
    ).strip()


async def openalex_get(client, params):
    """
    Retry transient provider/network failures.
    Do not retry indefinitely.
    """
    last_error = None

    for attempt in range(3):
        try:
            response = await client.get(
                OPENALEX_URL,
                params=params,
            )

            # Retry rate limits and temporary server errors.
            if response.status_code == 429 or response.status_code >= 500:
                response.raise_for_status()

            response.raise_for_status()
            return response.json()

        except (httpx.TimeoutException, httpx.NetworkError,
                httpx.HTTPStatusError) as exc:
            last_error = exc

            retryable = (
                not isinstance(exc, httpx.HTTPStatusError)
                or exc.response.status_code == 429
                or exc.response.status_code >= 500
            )

            if not retryable or attempt == 2:
                break

            await asyncio.sleep(1 + attempt)

    raise HTTPException(
        status_code=502,
        detail=(
            "OpenAlex could not be reached after retries. "
            "Check AWS outbound internet access and OpenAlex availability."
        ),
    ) from last_error


# --------------------------------------------------
# SINGLE-PAGE OPENALEX SEARCH
# --------------------------------------------------

async def fetch_openalex_papers(topic, page=1, per_page=20):
    params = {
        "search": topic,
        "page": page,
        "per-page": per_page,
        "sort": "relevance_score:desc",
    }

    timeout = httpx.Timeout(15.0, connect=8.0)

    async with httpx.AsyncClient(
        timeout=timeout,
        follow_redirects=True,
        headers=OPENALEX_HEADERS,
    ) as client:
        result = await openalex_get(client, params)

    papers = []
    seen = set()

    for work in result.get("results", []):
        paper = convert_openalex_work(work)
        key = deduplication_key(paper)

        if not key or key in seen:
            continue

        seen.add(key)
        papers.append(paper)

    return result, papers


# --------------------------------------------------
# AUTOMATIC CURSOR PAGINATION
# --------------------------------------------------

async def fetch_all_openalex_papers(
    topic,
    max_papers=None,
    batch_size=100,
):
    """
    Retrieve OpenAlex results using cursor pagination.
    A None max_papers value continues until no next cursor remains.
    """

    batch_size = max(1, min(int(batch_size), 100))
    cursor = "*"
    all_papers = []
    seen = set()

    timeout = httpx.Timeout(15.0, connect=8.0)

    async with httpx.AsyncClient(
        timeout=timeout,
        follow_redirects=True,
        headers=OPENALEX_HEADERS,
    ) as client:
        while cursor:
            params = {
                "search": topic,
                "per-page": batch_size,
                "sort": "relevance_score:desc",
                "cursor": cursor,
            }

            result = await openalex_get(client, params)
            works = result.get("results", [])

            if not works:
                break

            for work in works:
                paper = convert_openalex_work(work)
                key = deduplication_key(paper)

                if not key or key in seen:
                    continue

                seen.add(key)
                all_papers.append(paper)

                if (
                    max_papers is not None
                    and len(all_papers) >= max_papers
                ):
                    return all_papers[:max_papers]

            next_cursor = (result.get("meta") or {}).get(
                "next_cursor"
            )

            if not next_cursor or next_cursor == cursor:
                break

            cursor = next_cursor

    return all_papers


# --------------------------------------------------
# AI SIMILARITY RANKING
# --------------------------------------------------

def rank_papers(topic, papers, batch_size=32):
    if not papers:
        return []

    model = get_embedding_model()

    query_embedding = model.encode(
        [topic],
        normalize_embeddings=True,
        show_progress_bar=False,
    )

    scored_papers = []

    for start in range(0, len(papers), batch_size):
        batch = papers[start:start + batch_size]

        titles = [
            (paper.get("title") or "").strip()
            for paper in batch
        ]
        abstracts = [
            (paper.get("abstract") or "").strip()
            for paper in batch
        ]

        title_embeddings = model.encode(
            titles,
            normalize_embeddings=True,
            show_progress_bar=False,
            batch_size=batch_size,
        )

        title_scores = cosine_similarity(
            query_embedding,
            title_embeddings,
        )[0]

        abstract_indexes = [
            i for i, abstract in enumerate(abstracts)
            if abstract
        ]

        abstract_scores = {}

        if abstract_indexes:
            abstract_texts = [
                abstracts[i] for i in abstract_indexes
            ]

            abstract_embeddings = model.encode(
                abstract_texts,
                normalize_embeddings=True,
                show_progress_bar=False,
                batch_size=batch_size,
            )

            scores = cosine_similarity(
                query_embedding,
                abstract_embeddings,
            )[0]

            abstract_scores = {
                index: float(score)
                for index, score in zip(abstract_indexes, scores)
            }

        for index, paper in enumerate(batch):
            title_score = float(title_scores[index])

            if index in abstract_scores:
                abstract_score = abstract_scores[index]
                final_score = (
                    0.35 * title_score
                    + 0.65 * abstract_score
                )
                paper["has_abstract"] = True
                paper["abstract_similarity"] = round(
                    abstract_score, 4
                )
            else:
                final_score = title_score
                paper["has_abstract"] = False
                paper["abstract_similarity"] = None

            paper["title_similarity"] = round(title_score, 4)
            paper["similarity_score"] = round(final_score, 4)
            scored_papers.append(paper)

    scored_papers.sort(
        key=lambda paper: paper["similarity_score"],
        reverse=True,
    )

    return scored_papers


# --------------------------------------------------
# RESEARCH GAP ANALYSIS
# --------------------------------------------------

def normalize_concept(value):
    if not isinstance(value, str):
        return ""

    value = value.casefold().strip()
    value = re.sub(r"[^a-z0-9\s-]", " ", value)
    return " ".join(value.split())


def build_gap_analysis(topic, papers):
    usable_papers = [
        paper for paper in papers
        if paper.get("title") or paper.get("abstract")
    ]

    abstract_count = sum(
        bool(paper.get("abstract"))
        for paper in usable_papers
    )
    paper_count = len(usable_papers)

    base = {
        "topic": topic,
        "provider": "OpenAlex",
        "paper_count": paper_count,
        "abstract_count": abstract_count,
        "abstract_coverage_percent": round(
            100 * abstract_count / paper_count, 1
        ) if paper_count else 0,
        "themes": [],
        "candidate_gaps": [],
    }

    if paper_count < 3:
        return {
            **base,
            "status": "insufficient_evidence",
            "message": "At least 3 usable papers are needed.",
            "limitations": [
                "Retrieved papers may not represent all relevant literature.",
                "Text frequency alone cannot establish novelty.",
            ],
        }

    documents = [
        f"{paper.get('title') or ''}. "
        f"{paper.get('abstract') or ''}"
        for paper in usable_papers
    ]

    try:
        vectorizer = TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),
            min_df=2,
            max_df=0.85,
            token_pattern=r"(?u)\b[a-zA-Z][a-zA-Z-]{2,}\b",
            max_features=1500,
        )
        matrix = vectorizer.fit_transform(documents)
        terms = vectorizer.get_feature_names_out()

    except ValueError:
        return {
            **base,
            "status": "insufficient_text",
            "message": "Not enough repeated text to identify themes.",
            "limitations": [
                "Text frequency alone cannot establish research novelty."
            ],
        }

    theme_items = []

    for column, term in enumerate(terms):
        indexes = matrix[:, column].nonzero()[0]
        count = len(indexes)

        if count < 2:
            continue

        mean_weight = sum(
            float(matrix[index, column])
            for index in indexes
        ) / count

        supporting_papers = [
            {
                "title": usable_papers[index].get("title"),
                "year": usable_papers[index].get("year"),
                "url": usable_papers[index].get("url"),
            }
            for index in indexes[:5]
        ]

        theme_items.append({
            "theme": term,
            "paper_count": count,
            "coverage_percent": round(
                100 * count / paper_count, 1
            ),
            "mean_tfidf_weight": round(mean_weight, 4),
            "supporting_papers": supporting_papers,
        })

    themes = sorted(
        theme_items,
        key=lambda item: (
            -item["paper_count"],
            -item["mean_tfidf_weight"],
        ),
    )[:10]

    maximum_coverage_count = max(
        2, int(paper_count * 0.20)
    )

    underrepresented = [
        item for item in theme_items
        if 2 <= item["paper_count"] <= maximum_coverage_count
    ]

    underrepresented.sort(
        key=lambda item: (
            item["paper_count"],
            -item["mean_tfidf_weight"],
        )
    )

    candidate_gaps = []
    seen_concepts = set()

    for item in underrepresented:
        concept = normalize_concept(item["theme"])

        if not concept or concept in seen_concepts:
            continue

        seen_concepts.add(concept)

        candidate_gaps.append({
            "candidate": (
                f"Limited representation of '{item['theme']}' "
                "in the retrieved sample"
            ),
            "concept": item["theme"],
            "papers_mentioning": item["paper_count"],
            "coverage_percent": item["coverage_percent"],
            "evidence": item["supporting_papers"],
            "interpretation": (
                "This concept appears in a relatively small share "
                "of retrieved papers. Investigate further before "
                "treating it as a research gap."
            ),
        })

        if len(candidate_gaps) >= 10:
            break

    return {
        **base,
        "status": "completed",
        "method": "TF-IDF concept frequency across retrieved paper text",
        "message": (
            "Candidate gaps require verification against additional "
            "literature and full text where available."
        ),
        "themes": themes,
        "candidate_gaps": candidate_gaps,
        "limitations": [
            "Results depend on the retrieved literature.",
            "Missing abstracts can hide important research themes.",
            "Text frequency does not establish research novelty.",
            "Human review and further searches are required.",
        ],
    }


# --------------------------------------------------
# NOVELTY CANDIDATES
# --------------------------------------------------

def build_novelty_ideas(topic, gap_analysis):
    if gap_analysis.get("status") != "completed":
        return []

    generic_terms = {
        "using", "based", "approach", "method", "methods",
        "results", "study", "research", "analysis", "review",
        "application", "applications", "intelligence analysis",
    }

    ideas = []
    seen_concepts = set()

    for gap in gap_analysis.get("candidate_gaps", []):
        raw_concept = gap.get("concept", "")
        concept = normalize_concept(raw_concept)

        if not concept or concept in generic_terms:
            continue

        words = concept.split()

        if len(words) > 3 or any(len(word) < 3 for word in words):
            continue

        if concept in seen_concepts:
            continue

        seen_concepts.add(concept)

        evidence_titles = []
        supporting_details = []
        seen_titles = set()

        for paper in gap.get("evidence", []):
            title = paper.get("title")

            if not isinstance(title, str) or not title.strip():
                continue

            title = title.strip()
            title_key = normalize_concept(title)

            if not title_key or title_key in seen_titles:
                continue

            seen_titles.add(title_key)
            evidence_titles.append(title)

            supporting_details.append({
                "title": title,
                "year": paper.get("year"),
                "url": paper.get("url"),
            })

        if len(evidence_titles) < 2:
            continue

        ideas.append({
            "idea": (
                f"Investigate how '{raw_concept}' relates to {topic}, "
                "starting with a documented limitation in existing work."
            ),
            "based_on_gap": gap.get("candidate"),
            "research_question": (
                "What limitations remain in existing approaches "
                f"related to '{raw_concept}' in {topic}, and how "
                "could they be measured and addressed?"
            ),
            "possible_contribution": (
                "Identify a documented limitation, develop or adapt "
                "a method, compare it against relevant baselines, "
                "and evaluate it with suitable datasets and metrics."
            ),
            "evidence_paper_count": gap.get("papers_mentioning", 0),
            "evidence_coverage_percent": gap.get("coverage_percent", 0),
            "supporting_papers": evidence_titles,
            "supporting_paper_details": supporting_details,
            "verification_needed": [
                "Verify supporting paper records and publication details.",
                "Read limitations and future-work sections where available.",
                "Search for existing work addressing the same question.",
                "Check whether the gap reflects missing knowledge.",
                "Define suitable datasets, baselines, and metrics.",
            ],
            "novelty_status": "unverified_candidate",
        })

        if len(ideas) >= 5:
            break

    return ideas


# --------------------------------------------------
# API ROUTES
# --------------------------------------------------

@app.get("/")
def home():
    return {
        "message": "Cloud Research Engine API is running!",
        "status": "connected",
    }


@app.get("/api/health")
def health():
    return {"status": "healthy"}


@app.get("/api/provider-health")
async def provider_health():
    """Check whether this deployed backend can reach OpenAlex."""
    timeout = httpx.Timeout(8.0, connect=5.0)

    try:
        async with httpx.AsyncClient(
            timeout=timeout,
            follow_redirects=True,
            headers=OPENALEX_HEADERS,
        ) as client:
            result = await openalex_get(
                client,
                {"search": "machine learning", "per-page": 1},
            )

        return {
            "status": "connected",
            "provider": "OpenAlex",
            "results_returned": len(result.get("results", [])),
        }

    except HTTPException as exc:
        return {
            "status": "unavailable",
            "provider": "OpenAlex",
            "detail": exc.detail,
        }


# --------------------------------------------------
# RESEARCH SEARCH
# --------------------------------------------------

@app.post("/api/research/search")
async def search_research(request: ResearchQuery):
    topic = request.topic.strip()

    if not topic:
        raise HTTPException(
            status_code=400,
            detail="Please enter a research topic.",
        )

    # Keep the interactive search fast for AWS.
    search_limit = min(request.candidate_limit, 100)

    papers = await fetch_all_openalex_papers(
        topic,
        max_papers=search_limit,
        batch_size=100,
    )

    try:
        ranked_papers = await run_in_threadpool(
            rank_papers, topic, papers
        )
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail="AI ranking failed. Check the embedding model.",
        ) from exc

    start = (request.page - 1) * request.per_page
    end = start + request.per_page

    return {
        "topic": topic,
        "provider": "OpenAlex",
        "ranking_method": (
            "Sentence Transformers + weighted title/abstract "
            "cosine similarity across the retrieved candidate pool"
        ),
        "total_results": len(ranked_papers),
        "candidate_limit": search_limit,
        "page": request.page,
        "per_page": request.per_page,
        "papers": ranked_papers[start:end],
    }


# --------------------------------------------------
# SEARCH ALL
# --------------------------------------------------

@app.post("/api/research/search-all")
async def search_all_research(request: AllResearchQuery):
    topic = request.topic.strip()

    if not topic:
        raise HTTPException(
            status_code=400,
            detail="Please enter a research topic.",
        )

    papers = await fetch_all_openalex_papers(
        topic,
        max_papers=request.max_papers,
        batch_size=request.batch_size,
    )

    try:
        papers = await run_in_threadpool(
            rank_papers, topic, papers
        )
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail="AI ranking failed. Check the embedding model.",
        ) from exc

    return {
        "topic": topic,
        "provider": "OpenAlex",
        "ranking_method": (
            "Sentence Transformers + weighted title/abstract "
            "cosine similarity"
        ),
        "paper_count": len(papers),
        "max_papers": request.max_papers,
        "papers": papers,
    }


# --------------------------------------------------
# RESEARCH GAP ANALYSIS
# --------------------------------------------------

@app.post("/api/research/gaps")
async def analyze_research_gaps(request: GapAnalysisRequest):
    topic = request.topic.strip()

    if not topic:
        raise HTTPException(
            status_code=400,
            detail="Please enter a research topic.",
        )

    papers = await fetch_all_openalex_papers(
        topic,
        max_papers=request.max_papers,
        batch_size=100,
    )

    return await run_in_threadpool(
        build_gap_analysis, topic, papers
    )


# --------------------------------------------------
# NOVELTY ANALYSIS
# --------------------------------------------------

@app.post("/api/research/novelty")
async def analyze_research_novelty(
    request: NoveltyAnalysisRequest,
):
    topic = request.topic.strip()

    if not topic:
        raise HTTPException(
            status_code=400,
            detail="Please enter a research topic.",
        )

    papers = await fetch_all_openalex_papers(
        topic,
        max_papers=request.max_papers,
        batch_size=100,
    )

    gap_analysis = await run_in_threadpool(
        build_gap_analysis, topic, papers
    )

    ideas = await run_in_threadpool(
        build_novelty_ideas, topic, gap_analysis
    )

    return {
        "status": gap_analysis.get("status"),
        "topic": topic,
        "provider": "OpenAlex",
        "analysis_method": (
            "TF-IDF candidate concepts followed by "
            "rule-based research direction generation"
        ),
        "paper_count": gap_analysis.get("paper_count", 0),
        "abstract_count": gap_analysis.get("abstract_count", 0),
        "candidate_gap_count": len(
            gap_analysis.get("candidate_gaps", [])
        ),
        "novelty_ideas": ideas,
        "message": (
            "These are possible research directions, not confirmed "
            "novel contributions. Verify them against existing "
            "literature before making novelty claims."
        ),
        "limitations": gap_analysis.get("limitations", []),
    }
